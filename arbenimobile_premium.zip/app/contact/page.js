export default function Contact(){
  return (
    <div style={{padding:20}}>
      <h1>Contact</h1>
      <p>Magjistrale Prizren-Gjakove, Xerxe</p>
      <a href="https://wa.me/38348545516">WhatsApp</a>
    </div>
  )
}