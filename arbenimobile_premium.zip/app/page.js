export default function Home() {
  return (
    <main style={{padding:40,background:'#0a0a0a',color:'white',minHeight:'100vh'}}>
      <h1 style={{fontSize:40}}>ArbeniMobile</h1>
      <p>Professional Mobile Repair & Unlock Services</p>

      <div style={{marginTop:20}}>
        <a href="/booking" style={{background:'#2563eb',padding:10,color:'white',marginRight:10}}>Book Service</a>
        <a href="/contact" style={{border:'1px solid white',padding:10,color:'white'}}>Contact</a>
      </div>
    </main>
  );
}