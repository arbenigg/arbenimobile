export default function Track(){
  return (
    <div style={{padding:20}}>
      <h1>Track Repair</h1>
      <input placeholder="Enter phone"/>
      <button>Check</button>
    </div>
  )
}