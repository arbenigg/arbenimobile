export const metadata = {
  title: "ArbeniMobile",
  description: "Smartphone Shop & Service"
};

export default function RootLayout({ children }) {
  return (
    <html>
      <body style={{margin:0,fontFamily:'Arial'}}>{children}</body>
    </html>
  );
}