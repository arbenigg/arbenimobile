# ArbeniMobile Premium

## Run
npm install
npm run dev

## Deploy
Upload to Vercel
